
var firstChange = 18;
var secondChange = 23;
var helper = null;
 helper = firstChange;
 firstChange = secondChange;
 secondChange = helper;
console.log(firstChange);
console.log(secondChange);

