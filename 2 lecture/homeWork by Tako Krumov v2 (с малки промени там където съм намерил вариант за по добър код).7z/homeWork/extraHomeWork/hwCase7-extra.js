let noun = "cat";
var number = Math.floor(Math.random()*10);
if  (noun ) {
    if(noun === "cat"){
        console.log(number, noun);
    }else if(noun === "dog"){
        console.log(number, noun);
    }
}else{
    console.log("unknown command")
}
