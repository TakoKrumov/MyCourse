var suit = "diamonds";
var suitPossibilities = "clubs" || "hearts" || "diamonds" || "spades";
if(suitPossibilities){
    } if(suit === "clubs"){
         console.log("Clubs");
    } else if (suit === "hearts"){
         console.log("Hearts");
    } else if (suit === "diamonds"){
        console.log("Diamonds");
    } else if (suit === "spades"){
        console.log("Spades");
    }  else {
        console.log("Unknown command");
    }