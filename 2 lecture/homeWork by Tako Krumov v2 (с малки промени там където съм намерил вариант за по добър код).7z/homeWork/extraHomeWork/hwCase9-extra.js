var a = 6;
var b = 9;
var c = 1;
if ((a + b > c) && (a + c > b) && (b + c >a)) {
    console.log("a, b and c are side's of triangle.")
} else {
    console.log("a, b or c are not correct side's of triangle")
}