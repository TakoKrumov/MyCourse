var a = 15.3;
var b = 28.6;
var c = 11;
var check = c > a && b > c;
if (check) {
    console.log("C е между A и B");
}else{
    console.log("Това не е валиден отговор!");   
}
