const PAGE_IDS_LOGGED = ['cocktails', 'details', '404'];// 'something',
const LINK_LOGGED = ['cocktailsLink', 'welcomeMessage', 'logoutLink','loggedNav' ];// 'somethingLink',
const LOGGED_DO_NOT_SEE = ['login', 'register'];

const PAGE_IDS_GUEST = ['login', 'register', '404'];
const LINK_GUEST = ['registerLink'];
const GUEST_DO_NOT_SEE = ['cocktails', 'cocktailsLink', 'logoutLink', 'welcomeMessage','loggedNav','details'];// 'something', 'somethingLink',

const SERVER_URL = 'http://192.168.7.50:8080';