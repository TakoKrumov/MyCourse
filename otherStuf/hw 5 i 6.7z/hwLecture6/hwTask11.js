let numberOfArray = 4;
let arrayLength = 5;
let array = [];


for (let index = 0; index < numberOfArray; index ++) {
    array[index] = array.slice(index);
    for (let indexArrayLength = 0; indexArrayLength < arrayLength; indexArrayLength++) {
        array[index][indexArrayLength] = Math.round(Math.random()*10);
    }
}

console.log(array);