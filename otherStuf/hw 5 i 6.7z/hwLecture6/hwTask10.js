let inputArray = [2,1,1,2,3,3,2,2,2,1];
let helpArray = [];
let counter = 0;

for (let index = 0; index < inputArray.length; index++) {
    
    let compareToNext = inputArray[index] === inputArray[index + 1];
    let compareToPrevious = inputArray[index] === inputArray[index - 1];

    if ( compareToNext  || compareToPrevious) {
        helpArray[counter] = inputArray[index];
        counter++;
    }
}

