let array = [];
array.length = 10;

for (let index = 0; index < array.length; index++) {
    array[index] = index*3;
}
console.log("Output:",array);

