let input = '23456789TJQKA';

function drawFromDeck (a) {
    let arr = a.split("");
    let flag = true;
    let controlInput = '23456789TJQKA'

    if(typeof a !== "string" || a.length !== controlInput.length) {
        flag = false;
        return console.log("Invalid cards given!");
    } else {

        for (let i=0; i<a.length; i++) {
            if(a.charAt(i) !== controlInput.charAt(i)) {
                flag = false;
                return console.log("Invalid cards given!");
            }
        }
    }

    return a = arr[Math.floor(Math.random()*arr.length)].concat(" ",arr[Math.floor(Math.random()*arr.length)]," ",arr[Math.floor(Math.random()*arr.length)],
    " ",arr[Math.floor(Math.random()*arr.length)]," ",arr[Math.floor(Math.random()*arr.length)]);
   
}

function checkDraw (str) {
    
    let countBig = 0;
    for (let i=0; i>=0; i++) {
        let count = 0;
        let a = drawFromDeck(str);

        for (let j=0;j<a.length; j+=2) {
            
            if(a.charAt(j) === a.charAt(j-2) || a.charAt(j) === a.charAt(j+2) || a.charAt(j-2) === a.charAt(j+2)) {
                count++;

                if(count > 0) {
                    break;
                }
            }
        }

        if(count > 0) {
            countBig++;

            if (countBig===4) {
                
                return console.log(`Number of tries: ${i}`);                
            }
        
        } else if (count === 0) {
            countBig = 0;
        } 

    }
}
    
checkDraw(input);
