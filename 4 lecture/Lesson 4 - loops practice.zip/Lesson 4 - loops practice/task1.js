//Task1. Write a program that prints all numbers between -100 and 100. 
//Then print them backwards.


// pochvam ot -100
// increment
// repeat 
// while x is less than 100

for(let i=-100; i<=100; i++) {
    console.log(i);
}


