var b = function myFunction1() { // function expression
    let x = "Vargulev";
    console.log("Novoto za vas");
}

// b = 1;

if(typeof b === "function") {
    b();
}
