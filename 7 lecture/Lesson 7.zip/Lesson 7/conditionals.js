let a = "";
let b = 0;
let c = [];

// console.log(a || b || c);
console.log(c && a && b);