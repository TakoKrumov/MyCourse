// console.log("Hi");
// -------------
// console.log("Hi");
// &&&&&&&&&&&&
// ??????????

// function declaration
// keyword name , parentheses (parameters)
function greet(fullName) { // start block of  code
    console.log("Hi, " + fullName); // body
}// end of the block

// calling the function
greet();

