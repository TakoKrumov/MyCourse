"use strict"
// hoisting is moving the declaration on top of the file
var myVariable;
console.log(myVariable);

myVariable = 5;

// myVarible = 6;

// console.log(myVariable);
// console.log(myVarible);