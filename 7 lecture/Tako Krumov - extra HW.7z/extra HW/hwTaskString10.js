let input = "Hello";
let result = "";

for (let i=input.length-1; i>=0; i--) {
    result += input.charAt(i) 
    
}
console.log(result);