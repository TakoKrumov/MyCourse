let input = "I love programming";
let character = "o";
let results = input.indexOf(character);

console.log(results);