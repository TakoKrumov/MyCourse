let input = "I love programming";
let character = "o";
let results = input.lastIndexOf(character);

console.log(results);