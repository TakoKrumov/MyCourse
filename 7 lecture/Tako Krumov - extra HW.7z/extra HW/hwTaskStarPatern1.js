let input = "*";
let row = 6;
let colum = 6;
let results = "";

for (let i=0; i<=colum; i++) {
    
    for (let j=0; j<=row; j++) {
        results += input;
    }
    results += "\n";
}
console.log(results);