let input = [11,22,33,-44,8,-2];
let copyInput = [];

for (let i=0; i<input.length; i++) {
    copyInput[i] = input[i];
}
console.log(copyInput);