let firstIn = "Never mind the dog";
let secondIn = "beware of the owner!";

let result = firstIn.concat(" ",secondIn);

console.log(result);