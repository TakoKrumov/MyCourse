for (let number = 1 ; number <= 100; number++) {
    console.log(number);   
};
