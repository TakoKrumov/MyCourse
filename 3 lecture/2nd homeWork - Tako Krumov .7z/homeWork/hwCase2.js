for (let number = -20; number <= 50; ++number) {
    console.log(number);
};
