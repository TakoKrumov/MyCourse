let digitV1 = 10;
let results = "";

do{
    results += `${digitV1} `;
    digitV1--;
    
}while(digitV1>=1);

console.log(results);
