let results = "";

for (let digit = 10; digit >= 1; digit--) {
    results += `${digit} `;
};

console.log(results);

