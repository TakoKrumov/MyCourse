var inputNumber = 24;
let sum = null;

for (let i = 1; i <= inputNumber; i++) {
    sum += i;
};

console.log(`Въведеното число:\n${inputNumber}\nРезултата е ${sum}`);