for (let number = -10; number <= 10; number++) {
    
    if ((number%2)!==0) {
        console.log(number);
    }
};
