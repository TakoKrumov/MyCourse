var digitV3=10;

switch(digitV3) {
    case 10:
    case  9:
    case  8:
    case  7:   
    case  6:
    case  5:
    case  4:
    case  3:
    case  2:
    case  1:
    console.log(`${digitV3--} ${digitV3--} ${digitV3--} ${digitV3--} ${digitV3--} ${digitV3--} ${digitV3--} ${digitV3--} ${digitV3--} ${digitV3} `);
    break;
}