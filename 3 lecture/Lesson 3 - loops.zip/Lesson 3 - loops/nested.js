for(let i=1; i<=4; i++) {
    console.log(`Smenqm guma nomer: ${i}`);
    // for(let j=1; j<=4; j++) {
    //     console.log(`   Stqgam bolt nomer: ${j}`);
    // }
};

if(true) {
    let name = "Slavi";
    if(true) {
        console.log(name);
    }
}

console.log(name);
