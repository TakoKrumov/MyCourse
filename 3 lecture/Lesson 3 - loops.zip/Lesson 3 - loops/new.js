// The condition will be checked first
// we use for known number of iterations
for(let i=1; i<=2; ++i ) {
    console.log(i);
}