
    console.log('Ringing...');
    isThereAnswer = Math.random() > 0