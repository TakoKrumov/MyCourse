let n = 1; // initializer

// FIRST check the expression and then run the body
// keyword (boolean expression - conditional) 
while (n<=1000) { // start of the block of code
    console.log(n); // body
    n++; // increment
} // end of the block of code 