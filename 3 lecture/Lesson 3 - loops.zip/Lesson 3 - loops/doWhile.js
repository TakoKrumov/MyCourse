let n = 1; 
// the body will be executed AT LEAST ONCE
do { 
    console.log(n);
    n++; 
} while (n<=1000);