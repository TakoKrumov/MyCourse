let image = document.getElementById("image");
image.style.left = "0px";
image.style.top = "0px";
image.style.width = '300px';
image.style.height = '300px';
let container = document.getElementById("container");
container.addEventListener('keydown', arrowKeyStroke);
let left = 0;
let top = 0;
let right = 0;
let bottom = 0;

function arrowKeyStroke(e) {
    var keyValue = e.keyCode;
  switch (keyValue) {
    case 37:
        left -= 10;
      image.style.left = `${left}px`;
      
      break;
    case 38:
        top -=10;
        image.style.top = `${top}px`;
      break;
    case 39:
        right +=10;
        image.style.left = `${right}px`;
      break;
    case 40:
        bottom +=10;
        image.style.top= `${bottom}px`;
      break;
  }
}


